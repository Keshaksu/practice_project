﻿//Тема №4. Игра на развитие памяти (Есть перевернутые квадратики с изображениями. Если мы откроем подряд два одинаковых изображения, то они исчезают.
//Открытие несовпадающего изображения закрывает ранее открытый квадрат). Можно использовать квадратики с числами.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrainingPractice_02
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}

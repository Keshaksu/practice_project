﻿using System;
using System.Windows.Forms;

namespace TrainingPractice_02
{
    public partial class RulesGame : Form
    {
        public RulesGame()
        {
            InitializeComponent();
        }

        private void ok_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

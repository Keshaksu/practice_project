﻿using System;
using System.Windows.Forms;
using System.IO;

namespace TrainingPractice_02
{
    public partial class Standings : Form
    {
        public Standings()
        {
            InitializeComponent();
        }

        private void Standings_Load(object sender, EventArgs e)
        {
            StreamReader tabletyrn = new StreamReader("Text.txt", true);
            label2.Text = tabletyrn.ReadToEnd();
            tabletyrn.Close();
        }
    }
}

﻿using System;
using System.Windows.Forms;
using System.IO;

namespace TrainingPractice_02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void rules_Click(object sender, EventArgs e)
        {
            RulesGame rulesGame = new RulesGame();
            rulesGame.Show();
        }

        private void play_Click(object sender, EventArgs e)
        {
            PlayGame playGame = new PlayGame();
            playGame.Show();
            StreamWriter tabletyrn = new StreamWriter("Text.txt", true);
            tabletyrn.Write(textBox1.Text);
            tabletyrn.Close();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != null)
            {
                play.Enabled = true;
            }
        }

        private void tyrn_Click(object sender, EventArgs e)
        {
            Standings tyrn = new Standings();
            tyrn.Show();
        }
    }
}

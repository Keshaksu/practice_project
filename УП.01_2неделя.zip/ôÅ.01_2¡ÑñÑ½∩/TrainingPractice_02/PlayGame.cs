﻿using System;
using System.Windows.Forms;
using System.IO;

namespace TrainingPractice_02
{
    public partial class PlayGame : Form
    {
        int openCount = 0;
        int[] masPairs = new int[18]; 
        int[] openPairs = new int[2];
        int[] masAll = new int[36]; 
        int used = 0;
        int number1;
        int number2;
        int pictIndex = 0;
        int s = 60;
        PictureBox[] masboxes = new PictureBox[16];

        public PlayGame()
        {
            InitializeComponent();
            masboxes[0] = pictureBox1;
            masboxes[1] = pictureBox2;
            masboxes[2] = pictureBox3;
            masboxes[3] = pictureBox4;
            masboxes[4] = pictureBox5;
            masboxes[5] = pictureBox6;
            masboxes[6] = pictureBox7;
            masboxes[7] = pictureBox8;
            masboxes[8] = pictureBox9;
            masboxes[9] = pictureBox10;
            masboxes[10] = pictureBox11;
            masboxes[11] = pictureBox12;
            masboxes[12] = pictureBox13;
            masboxes[13] = pictureBox14;
            masboxes[14] = pictureBox15;
            masboxes[15] = pictureBox16;
        }
        private void PlayGame_Load(object sender, EventArgs e)
        {
            picture();
            Random rand = new Random();
            for (int i = 0; i < 18; i++) //выбор одной из 18 картинок
            {
                masPairs[i] = rand.Next(0, 18);
            }
            for (int i = 0; i < 16; i++) //проверка ячеек на занятость
            {
                masAll[i] = 1;
            }
            while (used != 8) //задается 8 пар
            {
                number1 = rand.Next(0, 16);
                number2 = rand.Next(0, 16);
                if (number1 == number2) continue;
                if ((masAll[number1] == 1) && (masAll[number2] == 1)) //заполнение picturebox
                {
                    masAll[number1] = masAll[number2] = masPairs[used];
                    used++;

                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            textBox1.Text = Convert.ToString(s);
            s = s - 1;
            if (s == -0)
            {
                GameOver over = new GameOver();
                over.Show();
                Close();
            }
            timer1.Start();

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            PictureBox pict = (PictureBox)sender;
            int index = Convert.ToInt32(pict.Tag);
            if(openCount == 1 && openPairs[0] == index)
            {
                return;
            }
            if (openCount == 2) //при открытие третьей, предыдущие две закрываются
            {
                picture();
                openCount = 0;
            }
            openPairs[openCount] = index;
            openCount++;
            if (openCount == 2 && masAll[openPairs[0]] == masAll[openPairs[1]]) //убирание пары, если картинки одинаковые
            {
                masboxes[openPairs[0]].Visible = false;
                masboxes[openPairs[1]].Visible = false;
                openCount = 0;
                pictIndex++;
                picture();
            }
            pict.BackgroundImage = imageList1.Images[masAll[index]];
            if (pictIndex == 8)
            {
                label2.Visible = true;
                label3.Visible = true;
                textBox2.Visible = true;
                button1.Visible = true;
                button2.Visible = true;
                timer1.Stop();
                textBox2.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) * 2 + 10 * 8);
                StreamWriter tabletyrn = new StreamWriter("Text.txt", true);
                tabletyrn.WriteLine("   " + textBox2.Text);
                tabletyrn.Close();
            }
        }

        public void picture() //для закрытия картинок
        {
            pictureBox1.BackgroundImage = imageList1.Images[18];
            pictureBox2.BackgroundImage = imageList1.Images[18];
            pictureBox3.BackgroundImage = imageList1.Images[18];
            pictureBox4.BackgroundImage = imageList1.Images[18];
            pictureBox5.BackgroundImage = imageList1.Images[18];
            pictureBox6.BackgroundImage = imageList1.Images[18];
            pictureBox7.BackgroundImage = imageList1.Images[18];
            pictureBox8.BackgroundImage = imageList1.Images[18];
            pictureBox9.BackgroundImage = imageList1.Images[18];
            pictureBox10.BackgroundImage = imageList1.Images[18];
            pictureBox11.BackgroundImage = imageList1.Images[18];
            pictureBox12.BackgroundImage = imageList1.Images[18];
            pictureBox13.BackgroundImage = imageList1.Images[18];
            pictureBox14.BackgroundImage = imageList1.Images[18];
            pictureBox15.BackgroundImage = imageList1.Images[18];
            pictureBox16.BackgroundImage = imageList1.Images[18];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Standings tyrn = new Standings();
            tyrn.Show();
        }
    }
}
